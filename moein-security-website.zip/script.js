/* ============================================================================
   MOEIN SECURITY — BUSINESS CONFIG
   این بخش تنها جایی است که باید برای بروزرسانی اطلاعات واقعی ویرایش شود.
   EDIT THIS BLOCK ONLY to update real business info — nothing else in the
   site needs to change.
   ============================================================================ */
const BUSINESS_CONFIG = {
  // شماره تماس واقعی کسب‌وکار را اینجا وارد کنید (فرمت بین‌المللی یا محلی)
  // Paste the real phone number here exactly as provided, e.g. "09123456789"
  phone: "09365898801",   // شماره تماس رسمی کسب‌وکار

  // آیا همین شماره در واتس‌اپ فعال است؟
  whatsappEnabled: true,  // شماره واتس‌اپ با فرمت بین‌المللی و بدون + وارد شود (مثال: 989123456789)
  whatsappNumber: "",     // اگر خالی بماند، از phone (پاکسازی‌شده) استفاده می‌شود

  instagramHandle: "moein.security.gorgan",
  instagramUrl: "https://instagram.com/moein.security.gorgan",

  // مسیر عکس واقعی معین — عکس آپلودشده در پوشه assets قرار دارد
  ownerPhoto: "assets/moein-portrait.jpg",
  ownerName: "معین",
  ownerRole: "مؤسس معین سکیوریتی",

  city: "گرگان، گلستان",
};

/* ============================================================================
   Render config-driven elements
   ============================================================================ */
(function renderConfig(){
  const digitsOnly = (s) => (s || "").replace(/[^\d+]/g, "");
  const phoneRaw = digitsOnly(BUSINESS_CONFIG.phone);
  const hasPhone = phoneRaw.length > 0;
  const phoneDisplay = hasPhone ? BUSINESS_CONFIG.phone : "شماره تماس به‌زودی ثبت می‌شود";
  const telHref = hasPhone ? `tel:${phoneRaw}` : null;

  const waNumber = digitsOnly(BUSINESS_CONFIG.whatsappNumber) || phoneRaw.replace(/^0/, "98");
  const waHref = (BUSINESS_CONFIG.whatsappEnabled && waNumber)
    ? `https://wa.me/${waNumber}`
    : null;

  document.querySelectorAll("[data-phone-text]").forEach(el => { el.textContent = phoneDisplay; });

  document.querySelectorAll("[data-phone-link]").forEach(el => {
    if (telHref){
      el.setAttribute("href", telHref);
      el.classList.remove("is-disabled");
    } else {
      el.setAttribute("href", "#contact");
      el.classList.add("is-disabled");
      el.setAttribute("aria-disabled", "true");
      el.title = "شماره تماس هنوز ثبت نشده — به فرم تماس مراجعه کنید";
    }
  });

  document.querySelectorAll("[data-whatsapp-link]").forEach(el => {
    if (waHref){
      el.setAttribute("href", waHref);
      el.setAttribute("target", "_blank");
      el.setAttribute("rel", "noopener");
    } else {
      el.setAttribute("href", "#contact");
      el.classList.add("is-disabled");
    }
  });

  document.querySelectorAll("[data-instagram-link]").forEach(el => {
    el.setAttribute("href", BUSINESS_CONFIG.instagramUrl);
    el.setAttribute("target", "_blank");
    el.setAttribute("rel", "noopener");
  });
  document.querySelectorAll("[data-instagram-text]").forEach(el => {
    el.textContent = "@" + BUSINESS_CONFIG.instagramHandle;
  });

  document.querySelectorAll("[data-owner-photo]").forEach(el => {
    el.setAttribute("src", BUSINESS_CONFIG.ownerPhoto);
    el.setAttribute("alt", `${BUSINESS_CONFIG.ownerName} — ${BUSINESS_CONFIG.ownerRole}، معین سکیوریتی گرگان`);
  });
})();

/* ============================================================================
   Header scroll state
   ============================================================================ */
const header = document.querySelector(".site-header");
const onScroll = () => {
  header.classList.toggle("is-scrolled", window.scrollY > 12);
};
onScroll();
window.addEventListener("scroll", onScroll, { passive: true });

/* ============================================================================
   Mobile nav
   ============================================================================ */
const hamburger = document.querySelector(".hamburger");
const mobileNav = document.querySelector(".mobile-nav");
hamburger?.addEventListener("click", () => {
  const open = hamburger.classList.toggle("is-open");
  mobileNav.classList.toggle("is-open", open);
  document.body.style.overflow = open ? "hidden" : "";
  hamburger.setAttribute("aria-expanded", String(open));
});
mobileNav?.querySelectorAll("a").forEach(a => {
  a.addEventListener("click", () => {
    hamburger.classList.remove("is-open");
    mobileNav.classList.remove("is-open");
    document.body.style.overflow = "";
  });
});

/* ============================================================================
   Scroll reveal (single IntersectionObserver, staggered by DOM order)
   ============================================================================ */
const revealTargets = document.querySelectorAll(".reveal, .service-card, .why-item, .project-card");
const io = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting){
      entry.target.classList.add("is-visible");
      io.unobserve(entry.target);
    }
  });
}, { threshold: 0.15, rootMargin: "0px 0px -8% 0px" });
revealTargets.forEach((el, i) => {
  el.style.transitionDelay = `${Math.min(i % 6, 6) * 70}ms`;
  io.observe(el);
});

/* ============================================================================
   Projects filter
   ============================================================================ */
const tabs = document.querySelectorAll(".tab-btn");
const projectCards = document.querySelectorAll(".project-card");
tabs.forEach(tab => {
  tab.addEventListener("click", () => {
    tabs.forEach(t => t.classList.remove("is-active"));
    tab.classList.add("is-active");
    const cat = tab.dataset.filter;
    projectCards.forEach(card => {
      const show = cat === "all" || card.dataset.category === cat;
      card.hidden = !show;
    });
  });
});

/* ============================================================================
   Contact form (no backend wired — shows confirmation state)
   ============================================================================ */
const form = document.querySelector("#lead-form");
const formSuccess = document.querySelector("#form-success");
form?.addEventListener("submit", (e) => {
  e.preventDefault();
  if (!form.checkValidity()){
    form.reportValidity();
    return;
  }
  formSuccess.classList.add("is-visible");
  form.reset();
  formSuccess.scrollIntoView({ behavior: "smooth", block: "center" });
});
